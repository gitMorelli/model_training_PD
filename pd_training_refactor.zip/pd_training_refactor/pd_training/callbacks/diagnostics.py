"""Diagnostics that used to live inside the LightningModule.

None of these change training; add or drop them in the Trainer's callback list.
"""
from __future__ import annotations

import logging
from typing import Sequence

import lightning as L

from ..logging_utils import rank_zero_logger

info, warning = rank_zero_logger(__name__)

_WHITE, _RED, _RESET = "\033[97m", "\033[91m", "\033[0m"


class ParameterSummary(L.Callback):
    """At the end of the listed epochs (0-based), log every parameter with its
    shape, size and current learning rate, plus run-level counts.

    `color=True` adds ANSI colours (white = trainable, red = frozen); leave it
    off when the log goes to a file.
    """

    def __init__(self, epochs: Sequence[int] = (0, 5), color: bool = False):
        self.epochs = set(epochs)
        self.color = color

    def _c(self, text, colour):
        return f"{colour}{text}{_RESET}" if self.color else text

    def on_train_start(self, trainer, pl_module):
        info(f"Device of model at start of training: {pl_module.device}")

    def on_train_epoch_end(self, trainer, pl_module):
        epoch = trainer.current_epoch
        if epoch not in self.epochs:
            return

        param_lr = {}
        for opt in trainer.optimizers:
            for group in opt.param_groups:
                for p in group["params"]:
                    param_lr[id(p)] = (group["lr"], group.get("lr_name", "?"))

        lines, n_train, n_frozen = [], 0, 0
        model = getattr(pl_module, "model", pl_module)
        for name, p in model.named_parameters():
            row = f"  - {name} | Shape: {list(p.shape)} | Parameters: {p.numel():,}"
            if p.requires_grad:
                lr, lr_name = param_lr.get(id(p), (None, None))
                row += f" | LR: {lr:.3e} ({lr_name})" if lr is not None else " | LR: NOT IN OPTIMIZER"
                lines.append(self._c(row, _WHITE))
                n_train += p.numel()
            else:
                lines.append(self._c(row + " | frozen", _RED))
                n_frozen += p.numel()

        out = [f"--- Epoch {epoch + 1} summary ---",
               f"Total parameters: {n_train + n_frozen:,} | "
               f"{self._c(f'Trainable: {n_train:,}', _WHITE)} | "
               f"{self._c(f'Non-trainable: {n_frozen:,}', _RED)}",
               f"Expected number of stepping batches: {trainer.estimated_stepping_batches}"]
        if hasattr(pl_module, "train_samples_seen"):
            out.append(f"Training samples processed this epoch: {pl_module.train_samples_seen}")
        data_shape = getattr(pl_module, "data_shape", None)
        if data_shape is not None:
            out.append(f"Expected total units (subjects or groups): {data_shape.total_units}")
        if hasattr(pl_module, "describe"):
            out += pl_module.describe()
        out.append("Parameters:")
        info("\n".join(out + lines))


class GradientCheck(L.Callback):
    """After the very first backward pass, log the mean |grad| of parameters
    whose name contains one of `name_filters`, and warn below `threshold`."""

    def __init__(self, name_filters: Sequence[str] = ("layer4", "classifier"),
                 threshold: float = 1e-8):
        self.name_filters = tuple(name_filters)
        self.threshold = threshold
        self._done = False

    def on_after_backward(self, trainer, pl_module):
        # with gradient accumulation global_step stays 0 for several backwards
        if self._done:
            return
        self._done = True
        if trainer.global_step != 0:      # resumed run
            return
        lines = ["--- Gradient check (first batch) ---"]
        model = getattr(pl_module, "model", pl_module)
        for name, p in model.named_parameters():
            if p.grad is None or not p.requires_grad:
                continue
            if any(f in name for f in self.name_filters):
                g = p.grad.abs().mean().item()
                lines.append(f"{name}: mean |grad| = {g:.2e}")
                if g < self.threshold:
                    lines.append(f"  -> WARNING: potential vanishing gradient in {name}")
        info("\n".join(lines))


class NamedLRLogger(L.Callback):
    """Log `lr/<lr_name>` every step, once per lr_name (the first group with
    that name). Unlike Lightning's LearningRateMonitor, which logs one series
    per param group, this gives one curve per logical group.

    Logged at batch start: by on_train_batch_end the scheduler has already
    stepped, so the value there would belong to the next step."""

    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx):
        seen = set()
        for opt in trainer.optimizers:
            for g in opt.param_groups:
                name = g.get("lr_name")
                if name and name not in seen:
                    pl_module.log(f"lr/{name}", g["lr"], on_step=True, on_epoch=False)
                    seen.add(name)
